// src/components/ToDoList.jsx
import React from 'react';
import { View, Text } from 'react-native';

const ToDoList = () => {
  return (
    <View>
      <Text>To-Do List Placeholder</Text>
    </View>
  );
};

export default ToDoList;
